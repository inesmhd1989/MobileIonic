import { Guid } from "./Guid";
import { Produit } from "./Produit";
import { LigneProduit } from "./LigneProduit";

export class Fiche {

public Id: string;
public Designation: string;
public LignesProduits: Array<LigneProduit> = new Array<LigneProduit>();
constructor() {
    this.Id = Guid.newGuid();
}
}
