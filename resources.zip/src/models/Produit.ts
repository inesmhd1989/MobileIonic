import { Guid } from "./Guid";

export class Produit {
/**
 *
 */
public Id: string;
public Designation: string;

}
