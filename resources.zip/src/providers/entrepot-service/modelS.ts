export class ModelS {
    public Models: string;
}