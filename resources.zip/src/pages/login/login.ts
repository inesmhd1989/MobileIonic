import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { User } from "../../models/user";

import { BonEntreePage } from '../bon-entree/bon-entree';
import { MenuPage } from '../menu/menu';



@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  user = {} as User;

  constructor(private alertController: AlertController,
    public navCtrl: NavController, public navParams: NavParams) {
  }
  login()
  {
    this.navCtrl.push(MenuPage);
  }
}