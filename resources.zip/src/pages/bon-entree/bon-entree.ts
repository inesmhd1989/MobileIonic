import { Component, OnInit } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { BarcodeScanner, BarcodeScannerOptions } from '@ionic-native/barcode-scanner';
import * as pdfmake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { File } from '@ionic-native/file';
import { Guid } from '../../models/Guid';
import { Toast } from '@ionic-native/toast';
import { ToastController } from 'ionic-angular';
import { TokenType } from '@angular/compiler';

import { isActivatable } from 'ionic-angular/tap-click/tap-click';
import { LoginPage } from '../login/login';
import { MenuPage } from '../menu/menu';
import { LigneProduit } from '../../models/LigneProduit';
import { Fiche } from '../../models/Fiche';
import { EntrepotServiceProvider } from '../../providers/entrepot-service/entrepot-service';
import { FicheEntreePage } from '../fiche-entree/fiche-entree';

@Component({
  selector: 'page-bon-entree',
  templateUrl: 'bon-entree.html',
})
export class BonEntreePage implements OnInit {
  ngOnInit(): void {
    // this.getAllFiches();
 }
 //------------------------ pdf-------------
 fournisseurObj = {
  fournisseur: '',
  transporteur: '',
  equipeTechn: '',
  gsm: ''
}
tableObj=
{
    design : '',
    qte : '',
    
}
//----------------------------------
  scanData: any = {};
  Produits: Array<LigneProduit> = new Array<LigneProduit>();
  Fiche: Fiche = new Fiche();
  options: BarcodeScannerOptions;
  //---------Constructeur---------------
  constructor(public navCtrl: NavController, public navParams: NavParams, 
    private dataService : EntrepotServiceProvider, public file: File,
    private barcodeScanner: BarcodeScanner, public toastCtrl: ToastController) {
    this.Fiche.Id = Guid.newGuid();
    this.clearData();
  }
//-------------Fonction pdf --------------
makePdf() {
  pdfmake.vfs = pdfFonts.pdfMake.vfs;
  var makePdf = {
  content: [
      {
          columns: [
          {
              image :'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAX0AAADLCAIAAAAN/9TaAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAOwwAADsMBx2+oZAAAVgJJREFUeF7tXQegVMW53r2NXkSKl0u59A4iHUVRNEas2Es0lsSYWBJNXhJjzVOjscfEHjWm+iyxIAgCt/fCvYAgiL1Ejdhiie3C+86Z3dk508/u3r3LZfYZ3t6zc2b++eafb/7555+ZyA73cQg4BBwCmUUgktniXGkOAYeAQ2CH4x2nBA6BjkFg+/btbMHcnx0jU6ZKdbyTKaRdOQ4Bh0AcAcc7ThccAplGYJcybaTgOt7JtM658hwCDoGs4x12KMD0t20HHgSmwWHbbFeeRYfFyqVvbwSoNqq0OkVtb2/505V/VvCORy3BD6oHxsF/32xvw39JNwbNleKVdFbpQtzl4xCAEn711VcfffTR66+/vnXr1jfeeOM///nPl19+2dbWtouAo+MdYAFE3n333XeYz9tvv03+wheg9tlnnwEpfWeGvQIGiQHq2TDEhGn7asc3/kMf6+3ku/819r82vPdl2/ZvvvmK/hAoyM/SyzuWvU9PeMl/6v0/v1S2cJLxN9u/bmv7minOS5coXtvy0JVXX3313//+N4uJ5XcgBjAJgOS79EWK8L/+9a8333wzFV0kcL333ntvvfUWypKWiIcoBU35zTffICW+qASzrCbAQXH4fP11DGR8QbYaGV577bWPP/44xSHhgw8+QD5ESFoF8gX/QgB8ARqffvop+U7V2LJexmTIFl1GM8KhKTdt2nT77befeuqps2bNGjp0aO/evXv06NGvX7/i4uIZM2YcddRRP/vZz/76179u3Ljxv//9byfmIB3v3HPPPbvtttv48ePH+Z+xY8eSL+QzZsyYQYMGPfLII0RdtErTRujAowDyJfbOjjdrahquv6Hlzjvqb7zhjcoapNjy6N+bb7p57V13NN18y/tbXvAYIU5aPon4//NpxcsjRjL+dCxOWu82rW264Zame++ou/nGrc8uQ5pXVqyqvfHm1rvubr7x+nfXNft89HWMmwjrxfjL3NCXXXZZ3759UX0KC4uJzXcWT3znUKVQ4yfoYrdu3f7whz9oVNkoMUaOuXPn9u/fnyuLiIF/8UE7Ll68eNu2bUceeSRqN3HixBRrN3z48MGDB69bt46I19TUNGLEiMLCwgkTJogQoTio2Zw5c9CxOfvUholomrPOOgsdmNSIoEq+kCeQZ/78+bAy/vKXv6Cr41epMDYtqEqD0v/0pz/F1CnoHADjPPHEE9/97ne7dOkSkX2i0Sj7GH/uu+++F1988d/+9jeQprSL2YBjVI+OSqDjnZtvvpnDQkTsj3/8o4l0GFPC5wafRjwjZdvmLY/23/3xaO6aaM7ySHTp1Gkbfvub5f37LYvmlEUij0Uiyw5a9NXnn3iJkTxmwHwTI524UZPw/WBChtHs3befHDthaSSyJhp5OhJ5uri49TdXPT6i+KlIpDSaiydPTpr42XvvenaRb3PFCMvCg0Sa+ZxzzpHqjc1DVrdEPUMO0od77bXXhx9+aARZleCqq65SycYWd8MNN8CUmzJlik1F9D2HZltdXU2kKisr6969O30LCUgarr7HH388bC5pvzV2D5Ty7W9/W19TEN/nn39+11130aI5AZKuO32RHSSozDBeiGy01rRcaYuT3OhPIPGLLroI1qLXdzrLREzHO7///e9ZCKi6sM3z4IMPGnWCWiWkd8fmPjt2vLxs5TORnHWRSDP+i0bKBwwonz2vLi+/IRJpjUTwb8nwUZ9+uA2vQBn9+VT8Q02eeIY+nX2JRO89v+WZrvlN0QiybYxGa3r2qpyzsKxv30avlCgersqJvPvcBiJGTBpGJGNdLrzwwtS1k+SArjhgwACN5tGCHn30UaNgtLuyYyNs9Xnz5ok9nBtO+vTpgxkWcpg+fXq6aod8mpubST+pr6/v1asXl7NUna688kqupppRnf5Evhx77LGi8Cy8o0aNwowPIyVX/TRWGaTGyV9bWwtrjuVc6XdVAip/Xl7eQw89xGbeae2d2267jaNeUYOteCfmwaHzLM/KwP+9s3xZTSTSRAgiktcwtLD524uaunZrjOTWR6P4r278+C8/+oT10MSmVwxlEOPJJyLPDfThi5srPJbJxX91kZzaXr1bDz6ysd+g+pwIMmzAk+5dP9m40XMyxSkw7gBKeHzETk7b+Cc/+Um6BklY/ldfffXIkSPFDDnL6IILLgilZDTx6tWrxT4mml3nnnsuXoFvYtq0aVI6SKJnIh9MrwiS6HugNq5r5eTkiNni4T/+8Q/KoTZsSyt7zDHH6OXEXA+8c++996arBUUmvfPOOz21ik+yXnrpJZCd2ImkckrNYdYyWr58Oc08lD7YwJjhNDp7h/KOSDcUDhve8cnCmx+hsxPG8bt82xvLlj0NismJ1EYjFZgZDehfOXtaRV5BVSSKJ2tg7xQO+nzbv8mkDDn4M63tcAnHKMO3g3w7B17ibwiTbNu8bkUkWhnxMqyLRMp69qqePX9Vnz5V0QiyLY9EV0YiH25YH+ccP0efsCxmWp7Y4J0kOqH0FfgU165de/rpp1N4VRMxeCLgrE1CM377298aR1oUWlJSAj2Gf2fPPfdMV+2QD8s7qKw4t5LaevCSwFBie6+q4lzfA+9oGBw/wV8G/859992XxjpyWVF7B7LBzw3PGhJIGVbFfSzRsGnOO++8JBQga1+x4h0pRuShDe/4lW8DOxC+IayBf7/87NOq075TOmR44/gpFQMHrv3Rj97dsLFy/0X1g0c0jp1SNmhI6w2/8QgnAV4b6OWLth1feItfhIx8Y4VQEll6/3p704UXlBYWVY2fULbHgMZjj/ro5RdqT/pOyR57NI2ZXDl4aMPPf+YtzCdW2Dy6avuaZKj7EC2n86ykx0z2xWeffba0tJTorlQ7qVrDvxh2iMO6GHz/xj520kknkZzff/992DvG9PYJON6xfxE2INzhln3Gxt4hmCNbrFXD3pFysb14qpQohdg75AMnfYoFUVUZMmQIlupozsT7bolPdiaz4h1Nk4B3zBDETJy2F556ourgQ9cdd8yGo05ce/x3P/r889efeLx8/JSmgxeXTZy85Xe3gVcaz/h+7fQZjQd+u3rqrHdbN7y9YX3toYe2Hn/chsOOrltyzAfr13qc4VEEoYm2N8qq6hYfuu6oYzcec0rdYYvffXnz65UlpVMnbDjg4OpJUzb88hcQ77krr6yZsmfLgYdUTJn+el39v995r+7I41uPPb716ONqDzvi1fISnwrjq/Xahvrxj3+cNOOIMBI20XtVSHFY3bDxKbIuDyzcGPtSfn7+008/TWoMF0/q/h0WHJZ34N+xxw0pTzvtNK9NwvQu4t8RrSoKArF3OP+OEaJQCYi9A7Hvv/9+FenY40BzOOOMM7KTPpKWKg28YyybGjir589f7s+AKiLRZ3Jzag7Yt2b0yMpotDovvwzzrDGjm797WkmfnpXRSG1uHha5aubPq10wf2U0WhbJwVtPwNl8/jnE3eM7dLxPww/OfDySU+LP1J6NRGsOPKBy+vQKTN9y8/DWqiGFzT8899khRbWRSH1OPpa0SqZMrFq47zNwY0cjsDSejkQrTjqeTtyMdVHNs7gpEvGS4AMrhv5LH9LuAd5Bidddd51GF8lPXbt2raur47oi51hlhUcHO+igg2hB0i94OHPmTPqWcZ4lVoStI/uddBgyXcKH8+9oejKLw0033cQ1h56GjP4d2DuUd2hbcF9E2UgC+pyapVwTkzR0nrXPPvtYEpax6bH+0NLSYtTMnStBJngHoTLerGpHW+2suWCZJs/jG6mO5jbv1qepew+sWzVGPe9y3R5FTfsf2NilK9aefE9ztH7M6JZJE2sjUSSASxjM0njaKfEowVgMznOnnYY8sSIGL7KX57SpDSNHIAdkCJ9Oba9+DYsWV/cbAAc28vR82L17ruu7OxKg3KZoXjnWzk482TJoEE3L8o5UY1TjLUdMhAjuuOMO5Il4M0TNGIdHLOGzHY/rhPRPYhY1NDTAljGq/t133025DLyjt3fYmaDGrKCFYvmc8g78O0ZhKETkC2KXnnnmGeTAGnoa6jHyDvzKmGchbE9KLuQhxzJcSvorrT6nA7feeisExvSZJXpNxREk8aMf/eg3v/kNwh2+//3vz549mwb4UF7D1D6U3bdTEFAmeMd3+Lbh3xrwDtjEdyTDAFnXt0dzN493aiO5+LO2qLDpWwc1dO1WHc0BL4B31o4f3zp5YrXPKaCq0mh07WmnEksnZu9s3/H8id8Fp4CbkAae48bp0+qKh3ur5lHPr1zXe7f1Bx1R0X+glyaag1Ia+/Rq3K0fvtdHc+t9y6vpxBONzh3alkZ7Bx3s/PPP/8UvfoF/sQ5FPpidsX/iO7QNcW5YYCbd/uc//7mKd+jzYcOGwWWjn30QBcW/3/ve94z9HPFv8OnQjm20d5AhFv4hKj5wc9JK4QtbU/yJBTKwJFZziDCwd2x4RzTKUGWaCWfciV3RyDuYZ33yySeNjY2YxKEdITNtFAh86aWX/s///A/WvDUGCCTEKuQll1zyy1/+klYZmRAEgHllZSWqjHg/zZhEqokFPgT7cHNn0CKCnhCts8cee5DmQ0gn4uP1jb5TEA0nZCZ4Jx6xs331woUI54PdAeOlpKCgdp95FcOGwlrBE1DGmlEjGk85obxPL9gpDTk5JbCJZsyo2HtWGcgikgt6Qmxh0/nnkuhl+JLhDMKUa+05Zy8lxlE0twLMsnCfsskT8aUm13sIdzIcRmWDBuM7nmAGt2byuNoD9i7JyQX3geAQQFRz6kn+lM1qawzHO5x64U8oN4nHpxQgKo3YZ5577rmCggJxkOTMCgyMNkr24osvIkZO1X/ocy4SGhxkXM9CdL+NACQNOhWpKeEdfX9mWZKkJOYVXN0ktoiFUTr+G3kHLIbYXy4r9k9s+lF51qnwBx54IAluVNkgyGS//fbTm1SYOiHEgSIpZoXlS1AhMiEGVOf7ZIJ32vyFanzeq6+t3Hu/+nnz6mfMbD7+O18idPChh9aMntC89z7lI8e+eOtt2JHSfNZZtaPHNC7Yp3LatPc3bvzkw231c+Y2zZ5VPWN2/XEn/vfjj7/+/JNPX3vp8zfe+s+LL7d98c37b75UuWhhzcyZLfPm1+6970cfv/f6htbqiXs2zNu3atzITb/8JWZ5z192aeXYaY3z5pePn/hm/VpEQDfss3fdnJm182ZVf/uw9ze/4q/0Wy0QaNbRiWoWFRXBKrHJjV2VQIAfVVZxRkaVeO+992a37aimXddcc42edPBrbm4u9gqx/cc4zyIsIO23qo5BeYeN3zEaYlyCJUuW0K6eyjyL5R2pwIgLnzx5sooyCKRopi+++EL6OpENK3GIMNbPs0444QQN6ZCfEE4F5zR2jXY+0kGNMsE7dJ1705//+szYSY3jxtaMHr5m73lv1De0XnH5ysKixonTVg3s33LOD9979V/lhx5aP7CwccK4FcVFLz322NY1q1aMG9k8fmxl8aiKAw/etmVj1ffOfrxbt9rhw9YUdC094djNq5aVwf08amT92HFlk6a9VrFm3Z/+WDZ4cNO4MaUDd8M6/UfvvNV4xhllhcV1k8auKOq/6Y47Xq4tL50wvmH06MrxY1dNmfzqssd9X5HVxxi/AzuchLRreghlHHbugJ0KRgsF2vzUU0+JmbNlgZhI2Ihoi5EeRZ4fcsghcLKyJALe0a+j48VJkyZJndn6ysIjHnaexYqK71j8NnbUUPYOlxtpEVh82MklpUUKJhzG2Gyh0RXsioA5o4mKQFaYhLI5WI5SVgq6kyTKDO94C+mwTVfMmIklJDhZ4G3BCtSqfn0qCvLgvqnHhCgaWTlwUMXc2RUF+V7coO/NKR86ZE1xIaZmDZ77JlKaGy2fPHXFkKEIKYQ3pwbLVYMGrpwxE6/U+R6i8rxI6ajRVf37wwON5SpED67u3bdi/j6re/eB/xjTN5RV3qNL+W67IQfMvKqj+asj0apDD6CrY8ZWs+cdlh2kisU9fOWVVzBO6v2a6BLwCuktDuw/NBo7SIBNzxx/YTpjnGfBHKBbqIxY0fwxzxL3SVhaPQQQuF3Iqjw7e+UESI532EyAAHhHxddEYMo7KrLA2hOtmmi6kidYRqSb9UUYVWasDeA7S5qM8I7nkvFOtGicOQ/eHHBEXa7nwXmud6/m7gVYq8ITz7tcVNR48EHrCrqBYhqxbSISaRk3buPkCSCUumge/m3Iy8f8q2HYMCxLNeR61NMwZlT9YUdjCcz7npMDb3HrnnvVjyjGVqy6HG/FqqF3n+aDj6jv15/kiaW0ll49NvftC2cQnniFRnOaTzklaf+OaFZQe4eyg81oRhLDW2nsjVjv2Lx5s2a0xO5KjZFPxmEYRHBhcmO+jV8ZvGNfHZp/TU1NKvMsgglmSfBbaQxJI+/g3Al92DcQwOZ4fRMY7R3EoBsbEQlwAACc3Hom3VlIJAk5M8E75MxA2PSV0/eCGUKWyWGMlOflVOXC2PF4B17eskH9qmbPasgtqPPS5MJmqSoaVjNsGOyUJlgl0UhNTm7N5KlrCveAQeStiCPkZ9CglXvNrszP98kLi1O5zSNGYMoGUwjUA6uqvEf32lkLy3v1Bb8gAcjLs6e6dsOfIB2srJWh9CMOJytuNvAZ/Tsc79jkSRnq+eefHzhwoFFr6WELYicEJalOWmDJCDtgRPpImneMTGS/nqWvO+gSXg/pRA9QGHnH6N8BAtiSkiLvkHmWsRGRAJPWpUuXksMG9B8jwqYMsu73TPAOOeoG2DWceQZ2SNX27tGU37Wkb5/6n19Usc88mB6t3bt5NDRr9vobry4b5sX4re3abU1epO6UExvPOrO0ILe5V8/6/AIQCg7KqDpwUUVOZH33XqCVmll7Vf74fGxkR4aNufmlXfLXn3te/ZJjSrELtF9vJFg1YeL6399cNXmSZxB174ZYxIbFh7Re9KPqbt0bu3VriuZ78UQXX+g1i5Vb2bA/C1Y0gkTIOTKUTTizgv1J1Cd4HI0qC9eMNHYZuSEQUTR2OGsfOxVx5IWoiTa8w65nccJzVWZ/FXlHOhPU7xQhsJx99tmcIUkLyhLegXcPAYoak5NrX0yusRL/z3/+ky7biZqTdbSRskCZ4J14sM2Oj//1ZsWiBbWzZteOGNV63Il4/ubKstLCwnVTx9QMGfrS3Xegs6696KfVQ4fWjxlbvtfUz95664sv28r3nl87f0b19GnN3/Ni51//21+rB+3RuOekiuJhr/7jMWTScsKJ8Ps0jhjZNHMGVhq2bdlaPXxU/X771RSPfumyy/HK5uuuLRs9pmXChPIRI97b+Dz2dTUfdUT1xPG1Q4ubvn3gRx9h2Rs7S62Ix2jvYELx05/+FAveOCEMnyuuuAKBIeQ7/SC+A6ukMMjF5isvLzd2PwTU0VBg1uSBy2DRokXEISJ2bPoEJ9pJ1cbIO8gBcSWoET6oy+WXX87VCzXFTwhmQREk1Ih8jPYODnlAoAosNaN7C51WtbTc4bxDGBCtoDkJiCMd2ij4Mnr0aJxDiG0cdDJIvN0p9/FszCATvBNfpW6r/vFFS/Pz6rr3XNu1S2lR4dqrLqtYcuiavJzaHt1hB1V+64AXHri3YvJUfK/p1mVF167rzj+39VcXr+nbr6pn99Iu3apGjH7x1nvKDzsae8pre2A7RU7lwYeUX/mrNUNGVPUoqOpaAEf1pl9dUnv6WaU5BTU9+8BXXTNn71fvf6Bs9ozKXO8EjPKcLi1nnbXx+muW7zGosnt+ddeCpwu6NF9znb+d3ap5jH5l1qdItEo6tuMhO12iZZMFdZVjmGZOdidzSomQMxIEpFJuPAdnYTaXHO9wddEIiQP9wDUq3mFhoZkgWE7l3uJgRGw3t2+A4NDhvEPrC/I1tiDbRiz74DnIHWYvIs6tNHLnTJQJ3iGRfliofnbmLG/1Kup5c+BhqereozrX89R4m6dw6uDgAVXz59TlFcDjA/+Ot+w1bGhFMaZdiDP0vMjYtFU6fU/YR3AP4Vd4fCoHDVo2Y3pll3zsk4il8dazBiFPnLbjrVj16F2NsJ0+vWoRzQwaiuRU9uza1LeP5072XvEONqw49MivYjtXzW2o5x39UgiragifwTFO0tHs//7v/4xTLUQn4vRljnowWpIXpXxHHsLOUlXSxt4xTh9IKVh+Yq05lb3DwgVbCYJhTxlr8nAdksKC00tJ9bG4RjE8+uij9bhlxr/j2debN2viNjWjAqchsF5J2ETn+2SEd0A7ODdn+47avefjHCq4gdf5+x427l4Ezw46f0NOnuesGVrccsjR9V174Sfs6oRfuXXylC3T9yThy/ATNxV0aVi0sH50MYipmfiJx41rWnJsRbcCfG/KycEmjJb5MzeMHQ9+qcnL8dinT9/njjiuesAg8BqIxnNI79Zz4+79sTMDC1613o6NnLXfwXqWfzi8xcfe3tH3AfQo9vg4ujyML3C+wI2ieZ30RsT7sPIiwAzjpGqYpc+xSyBp3mFJTX+mDM7QseEdto7YnQTBEHSHMx80kxH8RIrGehC3oi89b5DNKmO8g4r86le/IkUbZ81UQo5k6eCBXR00zNpCQ3eOJJngHb9TtX2xfTt2ioNl/HUlbI+Klg4YWN+zq78vNIo1rJpBQyr3XVRX0IUsPHkROiNH1Y4ajd0M3op4JKcxt6Bq3uzVwwf727VymnIipUWDV+yzT02+v46OfaE5kaoJ42oKh2OGBYrxzk7t1bty0YFV/fo1+iV61LN7r7KiQR7Z+SYS7K/aJUvi11CY2yxF3qG6BXWEXSMtD3DRE2Y17IPpGA38Qz44IVRjuhM75eSTT9bU0GjvcD1EM5XYfffd2amQ3r9D8qEO4zVr1sDdw3KcWC/SmdG32epIz/3qKN5B0xx88MHG2ZZ+nKDUgzh1m2Uvs/pmTYpM8A6pLOIGG3918T8xr8krWF2Qv7R3900PP/jc+ReW9xiEc79wEGbdCce80lRTO3ef2t37rxs9saZXv3V3/n7zQw9VFhWtHT2ubsjgiqlT31hbv+m8C+oLejePm1DTq0fd6Wc8/8jDtePH1BUXIw0igF585B+N115X1Wu3prHja/v2r/nWwW+8sKF18ZKqPv2bxk+o7tFz3bVXr3/wvqVd8ivyu63Oy3s4J9J6tXe6mGWLhOUdlWKJvMM6EbFftGfPnnqLCb+uWrWKiI0IWmxlVvVVQjr4lx4hKq2sPe9IBWNrGop3SG6UdyAbtumLVoDUCCLXCpBP9tg7xHqFexibuYyNaJngiCOOsFTRnSJZpnjHX0f/8sv/vrZh/Qetre+1rN320mb4fTbdcEvZ6PFN8xdUjRy+8dqr4AOq+d5Z1ePGrp01t2zihDeba7e9/mrV3DnNM+fUT51ceeJRCALacvc9cCSvnTu/unjYczfesu2Dd+sPWdw0fdbaWXOq58zY9u6bLz1bUj16QtOCedXFozf87CfIc92Fl1aMnNg8b17lmJFbH/aOvPn3lvXvtzR/0Lr2XxvXfv7FZ95pg1bTLPk6unF2I+oWeOfhhx8mKiL18uy///4ajSQl0nD7J598UkzMeXkwf8FcTLM+YuQd4+hNZcA8y97eEXkHmJxyyimULjU0B3auqKjINt6hPR93dZ155pnsgST2GIq1vvbaa3cKTrERMjO8E7s2Ky5Q7EKsf9VXPoljt3KiCCbEPoY1w4vrjjuqokcveHbgqSnDVGvqZETorEHQoH9kcklB14aF+64qLsKdEN65GdGcVXsUrthnfnnXghpvYpWDrRWVC+aXjR9HTsbAGRfl/QeuO+F4BP6syfE2RuCtJ3t3+/crW7Efy19li524+rV/B47NR78fnXQVqVuXUyPwDvHvsETAfsevGvuF/ITDwEgIL3ZOGm0QHNTA0pxIQEbeYWunLy513kEMFNm0QaZU0u5KoEaEMe78Q9XgV9b36gz4d6S0vmXLFqgNfOGWpo0qGRYr6ZVkO/v6emZ4x4/g8c4n9Q5GQKQM2YT51vIn4JdBVLl/rFeksmhww4GLsOkBYcRrI3nw8rSOH79h8lgwTl2O55ppzM2tn7Jn3cCBYJyWaD7ilSvhYz5kcZ13VFgunNOVuZGWyVPqhg3zfEZ53uHwdd4+iW/V9O8PHzNO+QIflRbkvf9cK+nw/mnz+O+rb7Z/admQodazuA7DOg7xXTXroZJw3mW2U9Hvf/7zn1944QVWU8W+hyeY+OCoDZVtRfjIyDs2YzVJg6VuNsLIGL+DV9h5FpEHfQzH/VDq0Zg/uA8P6b/zne/oO3Z7845GhchyARancEYPIktV7WVEGCcf6RvRZuzMhjQZ4h0PLL+6Xlf3L4fAv6+sWFrp78yCPxj/1gwZ0njQAdVdupAVcW8Za/zY1kkTYKd4v+LfvPzWeftiYzrow99akVM1ZEjpvouw7wEk1RzNg5XUPGVKXfFQUJV34A4MnD59Gg88FCvr3q6IXH/VLLfbh5v8+yRih8N74viSWTWH0b+DQQkhcPjgik580HPYD55gJwQ2Z+ODEFWxSFZ3b7nlFtbkoWYU++Xwww/HaVVcf2MJjvyEeBAjsRp5h1hYWDVDFbh64U88RO1QcUwrsBNqwwbvkjLySY538CL2uFraCAiGQhxjx/KOyAh0mZJtaOBcVVWFAwanTp0qHSQ0tcD5hGRjnbE1rbS54xJljncIWCSG0DN8dux4rWT14/65yJgQgSmWDy5as+SIhl49vNMCc3NxRlfF1In1M+diAoV1dGzRqu7Wtfzww58dPQZr6ljbwivVRUXPHrAIz1u9a/nyqnJysfGicsIE74jCvAKYSJUDBtYec8zTu/XzS/GuDH2yW9d3tmwiXBO4tT0d6+hQI+zPQvgGHL2IlycXnONfcl84/ZD7yMnV8poP0pMBXzrUE5VFHBA5wllUVvoQy0M4edOrr+/EUqmsDe9gUoPDIrC2gipwlaJ/Yi0cH3bfaVjeYbsr4glF60CsL2A3bq1qb3uHbUoKMoc2WzV8R3g6HEAwD42WDgEB/ixuc+xOSkAZ5R3aMJ7+e1vUv2q+7NLSgw5cf8RhNfvuW3fppR+8+37DkcdWDR/TMnNu6eDit9aUvL5pc9m4yc17za4dP7l2/wM++6ptw2+vXzFgcMusBViGb/7lJe9v3VI5d0H1pFkte80rmTzlnRe2PP/YkyWFxXAzry4aUXf2WV99+EnDBRdW77+g5YijcULY+ttuDa6ae/dT+I1n5Vg22jsY6mlEnzjcqdSRIsOpEaLp9GO4dPLF8RS34q5iOhvegc+FvB5K3e15R+yleHLiiSfqqcey02aMd6RmjsoawnMMQojnlMaac60PW5IMIUm0QscZN5KSM8I7wXmMfxsEmCcRaerde+U/fL2s5PHiwRW9+lUXFq7o0WvdDTete+B+OI8rCwtX7z6wZPLkN8sqcD/Eivxo1eDBpfkF5SedvPHPD5aOGYcTlOEeWj5k8Mt//9u6K68o796zunBQaY/eT06f+s6mmF/DpxZ/hTPMxIrDTOQdTukx8IJ32P4jHfEslQB7GrDnwIZ6WGc259gm90waNdWGd3CBus11OlztLHlH1V1hGNKDgSwpRopYxnhH1bhSsqYPbYK2UC9uGTTUAGCpdRlIlgnekXhO/IUkcti7P3p63/Ff4/kXlPnHU3i7IjD5Gjy0ctgQzKf8I5kxdcp/dtrMNYWDEXzsbZLAOtfAQctm7VWGOGYvCNC73RgHD1b0H+Cd6I5N7f7NNut+d4s/1MTunyCbVMl2LO8awJAf47nu3HmDelWzoYMf/vCHmjmU6ADiEs+ZM0e6+1ystw3v4Pwdyjsabk2Od0SLgOaDqyngWuKmnGE5KDO8Y2nsiPhjZopb0vRjDObUjz76aEidzcbkmeAdXb193gH7+GzQtvF/LoavB8tbIBpcSrNu0pSN07HpAevf+Z5juCCvYcFBmIXV5eQiWNk7y33UqNrDD8MVFFjwqo/m4Tj31r2mN44c7m3gys0HYYGbXrrrXi9z/+wxXxKr+ZRKZuM8Szx/J8URacWKFZa+VWmyG2+80VLvQvFOqEpZ2jt6Ock5sGG5hsUkM7zD2pU4LYg7FFWPG44x0Lc1XHXkbp+d/dPBvBNrBn8DF3ih+fwLscWhJZILU8W7Nmv40MbhReAU764rbzU9t3zq2NWDB2H9C75nbK14Zo/+z8yaUZffDS5kGDuIA6oaM6KmcADczHBFr/UvWX/x1j/Ebmf3/ch2y1bKZjWuo3PzLM6hE6q70vGf3MCncjBrNBVnuxA3pM3HnnfC1sLmnFNxHV2UGXu4pC52S3AyxjsEH5AO9jdgtdEGfJLm+uuv1/MOjD7NDjv7gjo8ZUfyjr+STQ/n8SyRLX++F3uxcbfMKu920JzyM0/bfPlllT16NfTuic3oFYi4ffD2+sMWYy7W2MvbPlq98KD6q35dXjhwbUFXnA1W0a3L87++suroJf/E6YWRnJXRyMN5BW+XwA9H1nEQqtO+vAOlAe9grUfarkanskobfve731mO85ybmQS2WH5seAf+HZqbyD4qPkrR3qHZYiMo2XQuRcO4A7O9eYerPjmDDZ+jjjoKt4AZWx/XVCxcuFDPO9CuDz74ICzvWypAJpN1JO/EWMfbugWnAWKavbMyXnx2Fa582HzvHVvuv+e/X36x7e03Sxbs3zJrTt3EcTW4tG/79lce+tuqocNaZs8tGV74wp8eQDBD3RGH1k+eUT93Rt28Gf95+62P/vPxuntu33LnXa233/16ZfmX/vIVmc+RYw9TwVd1Xyh15cLEYI+8UhUXSgzc3AaFCzvbgk2O/RP2lbXhHfZeYw0BsYWipuQ+Cc7bzVXHxt4hRsS8efPCQkHStzfv+GNbTLsQb81urEfcJuZQ2CyqaXfc3WocXbDXVOpfs2/lLEnZkbwTcycTUvAcMJ494ltACYKoPOkkmC2N+XkIPi4ZsEfrlVdULDwAl1LUd+mCeJxn5s+tveAi3A9Ri8PDuhRgVtV00UWeXROLzAlE6XhNnhLneLIZ/Ts4egbnDf7v//4vTrHCB0cL4u5Q8p394PJZXBnKBvXqFcIYjCt2RVw6zPYEo8IZeQe9AsGB5KRBBM6S2pFKcXUEAjh1kFx0iY/NPTYa3uH6KmJe2Moa+ypNnAHeoSADJbFFcFnFY489hgAorkY47A1bYW3W0RFtaEn3xubu2AQdyjtxiqGrSgla8JebPv/mqzVTJuOWG+94HRydk1eAnZ/VQwfD44PIY+/AsKFDS/dbWI99ErjC2LtAPbd69l5f7fg65sgJskxsDS2tfmUxfEYc1TVBfffcc4+N4YM02P2IEEG9d4P7lb0O1EbJjLxDAxQtuzrdsYn7JMj9WZoX9fYOh5Lq0A+9HZQx3sGVOzjultMN+icCvnFkB8gaLn84y8HRZOuWDaoIdOZsSZuWzcI0Hcs7sXts42ZOwBwBTXyOo8Jmz/M3N3jUg/WspgMWlo4e7m2/8lbNc3FAT9URh1V07eZ9z8tBmHLDzFngndi0Khg35FtVqTaB1N5RaYz4nHsCF4ClQDDRQx2qgKPFxXFVX5aRd8JaGTj6i/CFzT3FlvMsasEZT70QOShjvAO3GuERrrk1zKKfhJK6HHroofqZmqUuZUOyjuQdEj7jmSGegzl+YWc8lgc/fda2Y+Ve02BVg3RwhGBZXm7JfvMqiofiEC/wTnNOpHrI8KcX7FfhHxWGkB8czFy6YEHihHaBZVKmHck8y4Z0VGnI5Xn6Dx3qsYBq79fA3i4bS4otOhTv2IzP5KY9yjt64S15h1YKc5NQRJwZ/w4qa3NMrRQ9PSthFobzs03KstP8nirvSA8nT732XgSzH+m39rrfLN199+ohg9YM6L9i8pQ3Wuq2XnVFxYCixllzmgYNW3fxLzY/9eSzY8at7NN39e69n+jTf9Pdd3mR0OkwbcRaQOmN/h1N7xIVKxTv4LQHS5cqvJjwrZAuas8+YXnHSILtwTtso+B8CexKsWHAUH5l/XyH3NunQhWxf0lcJkGR1BQNh2Dq3Sp7cjDzjr4ZcA5D+ivjx/J4ET2gkLYd77/x+uevvv6fN9/878efoCe1XHUt1rMqp+75zKhRDZdfDnL6bNuHb23c9FZry4dbX/i6DUsGZCdESvGBqkqBd4zrtcYOSRP85S9/sTR2CIPQHer6IuAySKJR2pV3cE+xftJhae9w9cKJi5p7CjmU2HmWdFUbN1hx94WKyg/eUW3oRZ5w2EmbhuYT1jomyoZ762HfJdGmWfuKjnfohhGNZ/TBBx9Me93oSjfmXwnjxXcLv11dtdS/+ByOZPy3NBp9ednSeCAymbLFFq3sx/lQ8lN7x8YLaCQgvX+HrQL5jg2EY8aMUQ2PRCRsHYQfN1SlSOJ25R39PcWQPDnegdi4TsvG5EERon+HQxgeMeOmdoQCkhBkqYIhqG/+/Pmp6wbrGxo3bhw97iuJZs3OV6x4R+w/FNl2sXdiYX4ejxDeIX4gfHl75aoSOJgj0VacCuZtv8p98eHHPGTJGrzvGyIOotRdOdIGg7kLNNJl8oB3jPzIJaAXFaiUG7u3jXmSqom9DkvvRq60T0CjBHBcNFnP0ijSD37wg+R6CO7JQ1SLSD2ipxa8g7Aase60XDAvlrr1sx5soSKmhwpksNI111yDsqhIRncyKzwSs9qF1sQBI8khk81v6XgH63xGJYNhqWmDpGue2DhO+cPjnbZ3Vq9aiTuwvN1b3jU1iEt+2T89y48NjP3n//9k9nzaSEtC9W0GWBV0rBYS9Gw+VMtxuiDO1pLOWfAQxg67+zxUzgh3TP0sTrbWdNG3tLQU9wVy/ZmrwllnnWUjrTQN5kfYsMoBzuZPvuP0VfHSMTZDsBJrTkq5DOfnI3ZRRV7Up4bgY8QBYn5kP0RxgODd1atXS+eDSQOVPS/qeOfee+/FCXLQRTSG+MFKLYJo6WUslmOsTc09iyVuuZCvcT9x2zt19Q/kRbCX4q+R3PuiOTdEIi+vfpasiNHZVnwzRLv4dxAPBq+tChMpUOxDvIjraPEE4yHO9EIUmQ0gNA0B+fTTT8dJUciE5kaKQMginJoY/7n0NkUgZ2xbxwoRpEK25GOsDpuA1It8ELQN3aD2Dq6+xEPQJSsw0uNDnnTv3l11e7Kl8JjgwFhDaAwVm5UHpRcVFc2dO1cfWwB7BzsVACPJhEMA8x14qXCvA93qqdF58hNiizEhOPLII1G6zTiENCgCjXjffffR4TyNPcsGzMyk0fEOFBE3EGC3ETlBDs4F8oV+sOeQcn86xY3HFcdDwv1Zk2/4YNpV9Yfrlx513LIzT/vT8SesvOV327/60vv569jZOuSodpo+nVL5pjUUF5gAAQoLh4nxT/Lia6+9BvS4zcpSaUW1w3F/RAYqBmmal19+GXenIH0oTaWJgTbywU4iYxWkCUi9iCRYTXvllVfokYMY/FFZPMSvrDphBkHS41fYLMk1FpUfl9tBeK5dSP4oCODgX+mJiywCaBcVAngdPyFDTk6NSUJ/QrZLly5FnDc4CPwIXsbIARsQ+zwxjIEiMX3DgSdYHcYx2OQ+wlCNmBx0HfiWjndEsTKEhe+iIRMsr0T/G5k7kR9IxyIjyjfb2+B8JgcYko2m5N128u+k3lTUFDfqlpFBOAcNm6FNS9mkSb2+sRaJLxZkplAW5HRVIS35wBolp8SCwjBlxgeECMYMdVxGWiTp2EzC8Q7VbJt2tdcw+5Qai8AoUqhSbBJLGYQd/WwySYXck8s/wwoXVsiw6fXVSW9uqqFCHADCgszJmXqGYQXIcHoD72jg4MYx4+gtpteQSHIoqKhHfK5XR6OysuTCcTEnOZcyCZSklaKmUIoVCYuzEZnkMhSzTWNBYbMyDmBh65icnmdGjLTUJYlMQts7ehDFbsaml7JYWLVIopLS3i4dUpJu7FD9X5VYNcpJ0xuHhOSA0ryVRPPZ1DTtciadoQZnTfsadcbYUsYuYEyQdJU76sX08A7p2FwDJAdWcm9R+PT6EXZcFYnAqH9iQ9pQkmWtk05m+aK9ForNbXzXEjoV+RrzT86ssM/WRnmMwmtIiv5k5Cl7mbM2pY53RIxsoFd1PBXi6eoSeo6QKoR+pKKvWHYY1QyLs7aMqknySRf47aF5NsiwtQ47GFi+G7Zq9ppmTGlsRJFE9KDpVTFsTbM/vYF3LOHQ9HlNE2K9EF59LK/ii7Glw9r/bO/V6LFYLqJRscrAnhmo7wY0B3ILM1eu9E9qHmrYkGMfDQ0ZocMCysaNGxGcwpqlqagmW1N9PiIg7BOj5MYERq3AwRFYMGLv3pHmSR4iMRQSa97cUCE2Is2QfKEKjHy4/AlW7HNNU6q0JZXGys53dbzzySefnH/++QjQxEXdiLlCfAEJ95R+sHEJlxwh5YIFC3AJNLRcrzSIp0IgA+IXEDOGt1Lcb4FDJLFPR0oQVIy77rqLpFFRA2qHXULYoYMzBxA+h5045ApzFfni2GOEEbKFPvDAAyTii/tgZzYAxJUyOGoXGwtxQa30TAPk9sc//lEKL3ZUtLa2cv3hkksuUe2PI/1h06ZNKBFBazjzFGF7ixcvxlE4KSoiyRnxonS7uSrDlpYWHLTKcevf//53KJJ0lyM6PO5TnjFjBrbdH3DAAccdd9zKlSuTkJaWCMLFmTUIxkM8JEKE9AqJ2Bm0C3aZ4sKySZMm4ZoqTXqIeuqpp7JXd+LAwCuuuEIqLcKOyZ3ULOcCB9X2XXDf8ccfjyuJsdXrW9/6FrZKIIckcMjmV3S8g/t2Ebt92mmnASMc3IkIVADx6aefiu2BwDB018MOOwzdBhSAKGdoD0YPac3xOhCHNuDItcrKSpxKRw6FhDomjRTUS3+GOQo944wzoNYqkXB6JiK4EEoP4kDnxK2MJ510EqRatGgRCcbj+jz+XLJkCXoImyEIF9fOikVgyAXlAUnoNDZYYVs5sBWToXtgHwb7nEKNCmLrEHBmf8VFoNzxCKyca9bg3NcITkTGLePYKYo/kR5PuCKSwBzBJohWB54iJmxuiCFGAPGyZctYhbngggsw0iDcVNQibKfAOao4MvW2227DMIYz5CHteeedl4SE5BWcDYarOEDxhOsxjqqGEDQcovh+/etf40hWpCf6iVMNVdSD6D6ENdMDFVEWtBfwSkXFgId2xxVg7K/QeXQZNric/gqSwjZaDCq4XgJwIWwa3RC7LpLGIQtf1PEOxivcx0y5Fue/FBcX33///Vw10DZQRLTrU089RX5CSoRjoneRP7nGg1GARkXrss/R1fEwaXBxzQDpBpoPzjNWcRMoEkMcWImLZ0V3xTYZ1fZu7FcAU7Algkk18f7ohzhmgZvBsa+jk+BYYmkVyDXhMAFYSPfff3+UKE2PIF2kh7nK/Xr77bfDlEADJaGLtL3uvPNOZA7qwd0GmnwQHYf9YmBzzFupGsAowIYDUABbEZIzDjbDNisqGx5iWEJB1157rYovNKXD2AGLETsalizGTtUmieuuuw67EzjzDeMQhMcgxBoptLgNGzbAfmRfAe9gf4NUHjAv2R1GDkUiGQIHzCTE9PgVtiTOFWJnDDgvBTmAl5Notex8Rcc7OKcSvEN5GoM2aFt6VBXUCP2T4oKU4B2oOK0zbTxsvcPW5JtuukmkJLQxxhBNt9QgCN4BC+gNaRXv4C0YIzDQ2N7IzQ7EiuAJ7BeYwWxFrr76as35TFDlUaNGwURXyQnewTgvVhNsiLJwKC80lVIPksEWg3Ugdgw8wTYiGKfSWhDV12OlgRq7H8AOMEkOP/xwjMaalBi3YEdgoodeBJuRpER/g+Em3V6DWRV+4rZu4pRoTHtBYWEFRvpzzjkH5h4ISFQ2mhsaHQaFdHYMkwTb6DAlFGGEvSPyDrbFs3pC38I+R8yyMRtAHyEWK36S8g55BTeC4i4KsnGEthSsVLgjwoKQnaQDqXS8A3rGRhLslENfQrUxe2Kv0WCrhI4BewFdF4SCERvMAm2T1hk2EYwmqoVsO2HnC3gtiWtY0Rjok+AdPcrnnnuuyt6B2YL5ueZ1TvPInzjcH4M55vlgPXxOPvlk/HnzzTer8gGDg3ewcUmVQGrvkLIwlkJ+2JVw1hCTCs+pvcOJBzcnqEFzNFIq6gs/CLlFC8YIxgnsFGO7B1s1TEPgp8ATKAOUB9v9UC4mL9TeIWJQYQjv0GMfyHN0VJjS4oU8llXA3AeGBuaYrGDsu/AMwNihu65YUobFAfsUM26xgtTeoVnB3qG8Qx+SL/ADogqoCAYDEBCZW3G8w77yyCOPgKnZDWv4lZxya38BSdYyDhFMxzswPQoLCzEaQG/QJTDyUP8CpzHgHZAxZsiYiELVYChyZ7LR9PCPog3YBSyKOMxgeHPpBvdQwMHVQnlHpZGsvcM2M77DjuDmj9AVTL8xWkJaeGQ4TSKyQXXQneCAAJ3BrQNeACnQ2aUoP+EderuLmEAzz4JOo454BZM1dCRiSyI9a+/QDDHCYxhgL7SF/CBEDNEYG+CwxDUGoeClidHQyIGYOZg9wQ2Bq2zIryLsICaITXYeAckRI0bgC/ZGQqO4eRbJgeMdWigMt+SO04VImEHD6kGPffrppzk5icDwoUDryGIfmwC/wrIjDmYOK/wE3oHrCixAa43Wh/Er1T3YhhhrkQnaBYQCvyFRHullZPgJvANForxD5v4wHjHvYz1KlsybXEO391s63sEpZ5hnge+54VSUCc5meFjhk8OwjGbmWIlVSrh1cCIJDoLi2hh/Qk1BW5iMhK0zioO9w9oyIk3gCXhHNRfD7VTc+S9QUzzB+TiwKdC7pIdLoEQ6zyIyo1NpzhjV8A4RGLkR/44I+CGHHAKTipSCrgKRoJc4K4u7BpcM10iDgZo7SQs1wqwHfQA2vMoaNSKP/oY2gjEFOsZyJIgMi5gwZMROiyc4fwdikykVuhw4Gp6ahx56COYSeYXTE8o77HNMu0DWYRd0uD6JTg5Tmr20kwoMdsaiKuIMONjxJ6wkcCXrnKLZrl+/Hsss5BhA8hBcDFWRAgjM4QsjXm24hDAbgLMCzmZ4u8nWc+5D51lsLeCfwqIkWY6QjoLGtsuqBAbegQm6YsUKIjHXluyfxK8MPcMkAnoJoFlouF4EU5NQPvfBQ85Na48UOpLxwDrwDrwkYp4QD8f0Qi+la9s4uID4C0UyhY0DDwt9ji8Y/DX3YSdh71DoIAO4lQqPqRZUGZgDaq5G5BVYN+AXdk5HnsOdgbkz+r89tmxKBElg5oLegjPVYQ7DW4cBHFQiHZkI71DTBov6OPABMmOZSXpEMXgHNibnqwaVQwmpPWI/yGMuDz8jFR7jIvzH0k4LA5DMB7kmBo/A1JIC9fzzz8PqpGsjeBGOCNVqKeUdUsTjjz8O8wc4QH/oOMGWQv3KrLRwD7EKkFzzZc9bOt5BwAhsE3jjpZrNggLewRgISsZDnHeHIAiyjiDVEsylsdAAiqHjJFSEnDiFfmKvWKxUaBJoM57ACsBERnquDWJzKN+JJIIJC9Z3MTDSfoKBDn0MlrZ43zl5/ZRTTsGxKWw1seqkWpBCspKSEgzdbGdgq4A8MW/CsCnldyxCwTtA0pMEZK1XdOLQ16HWaAj2KFVYDWArMGly+gcnCwZ5TPTY1xE2AX+N1E8M0xViwxam6bHyAJnhkGYD+eiv4B0QE0wPsBLW4wAX6ABWUnJRPLC+Ya0jhgD5Q2ZoMnEdigqG6RJSAi6qkJjyw/aEXaZa5YDDAUSGCC8YwsgQXktMgnDCDq0LWwqm3sCNDR2AVMCBHinNiYSZHQxJmDZ4BZ0FgyL8AMgBmKh6YnIN2oFv6XgHxiQch2yrq0gBioJBg86EsayDwZYYqNIPfIewz+E8wlvwF2DMhNFOBufkeAd8gYbEegH6FXKT2mhwxOjX2uH1gHZihgKp0NKwgPAdZ6NIpYKcmLZwS6e4vRcfVa3RD+E31VQTcX10msYxI+J3xOEUPgX24lqxXJhFgAX9ByAjahELQ8iEHscVVu2ACfExsR9MoFAp9mIMKjkmzhCbRs2QtzAg4SFZOuTaGtMWOE1gjkFg+IDgLkT3o1PysNIiPfQQVglGDsykiB9KHG9ItiA7NDrMEPhcUE2sxuJfdv7ISksygQ7DOoPAeBH8jgA3lfbCMYrTC+l4RkrEIhfGLS4gi/yEuA2MwVBjqB9eROb4l1UbVS2SgKijXtHxDqwGzOc5vKSCYviC5YlRgvwKOxxDK1npUH2g/WAH0lFhIkkHQHtQYObA5QbTDB8MPvT4bjYHmC0kBF7zgZEPKxc2y6WXXopuI51+09fJ2XRs5yFH26nyx/AF/eZ882xixL9S24pmS77AShINJTQNaFGjhfgJIsGVgEAeTFgwkNDiwvI7HLQAhDYx28ewqIw5lFhriAd8uNA4NDRkJjGlnAxQCXhP4XBBI0J/MG4lfXkLzRk+GgwPos0uSou2huZg6RYKCZ+mjUJCPGCL+Tt3fTCXOSaJMF64DIGACgdkCxzQKfCB0QcMVSG49h0k21Ka94WyEkunAOxDLoHYeKK6a163BIvreGKGqRehkgQ5cwRhlJmV1ognRxNsWKNx0NPAYhRSpCeuKaWSk7fITzb9lk0v0pD0ib3k3Ot6ntXrjKbQsPRNq6zvCBz+rJqFQiBrE6ftHAyuhmF7Y3sDZOylqQiQhPIl8YoooTETkR2Mr+hx0NCNZnyyYZAUBTOOjpbta6kn7afeacTBssodksyKd7jRIHXzIe3NxopER9rsbEI9ehq9l1ZHVceM1V3fUW1+bQ+9D6VgqWOVYg5S28eSAdsDvQzkacU7nD1sHHhDtbox81RQCKsQ7Z2es5+JIRCKUMQcVJamMWUoYMU2NWIl9hy9YrC/GjM3zn2SyMGyq4dtL40kYbMK1WTZnDgE77DWspShjR1ABUQSKmLkPr3Zr5dExQWpNySn2TYEHVZrpZMam/ZKvXa0aHuS4gRrDzmT0C7jKzYNx+Jp9HapcDBKkpZWy3wmIXhH1WekQofFK2x6PceFVYu0VCG9jadHWwWXHsbU+dSmmWzS2GOVYm72mmBp7NhLztmbRoZNIued95UQvKO3dwgELLgpaow9psZCU+9vGmJqj2pK89Qork2faQ85ua5lbDKjDMYExiJCGcJJ5Jaizd4eFUxjLTKWVTjeyZhYriCHgEOgEyPgeKcTN66rmkMgSxFwvJOlDePEcgh0YgQc73TixnVVcwhkKQKOd7K0YZxYDoFOjIDjnU7cuK5qDoEsRcDxTpY2jBPLIdCJEXC804kb11XNIZClCDjeydKGcWI5BDoxAo53OnHjuqo5BLIUAcc7WdowTiyHQCdGwPFOJ25cVzWHQJYi4HgnSxvGieUQ6MQION7pxI3rquYQyFIEHO9kacM4sRwCnRgBxzuduHFd1RwCWYqA450sbRgnlkOgEyPgeKcTN66rmkMgSxFwvJOlDePEcgh0YgQc73TixnVVcwhkKQKOd7K0YZxYDoFOjICcd7beOj+S+My/dWuyCHgZBV9ffjYyDjzaunw5l7+YRlq+mLmXTP40kYGfOf2cvZz+4lea+Zv84D31HgYhkWagAymVzH2JOcG8Z3ikkiqRPm1NmawKuPccAiICEt7hu4hM7ZOFMt6LA52d4zUhjaqw8LwjVCXAcDJuoMKY6MyESAqZx5gywDwx3mFKlQnYnk1pqrD73SGgRkDkHUm395Q8BaPHZAckm3VI3lEwB/NYTJEAI1Xekdhhtpn7HHPrrfNZnKx4J7NN6bqZQ8AaATnvaJmAsdwDQ7DseaC3sia//ybzIF6ikEYzdQrHO2oziunD+MrWnXknFO9Ia7Ej2cxj8gVet+adZEndWoNcQodAeARk/p24B0SmsqzlrvrO9IlEbw2Y/MHHtBxFmrTMszS8wf4U6NwsVdnzjroWSWYex5MVx4p3dnhU538c+4TvGu6NdkRAuZ7FDtkJpyan7vRPVa+kz/l+wvaleKdQpWlv3vF7Z9x0Y7ghYCEF8KBuZUl/1tUiucwTOUKIWImWvENd4zJHejuqlcvaIaBFwGYdnXG+SqYKfkcQuwEpNc470l7rvckQljJNJngnQSC0isGJma29o69FUpnLaDEM7zD4MU3pOoZDoOMQsOEdZm06Fd6R2voc74SaD7SDf8driFgdOX9QGN7R1CKZzAMcExMrSd4xhxl0nCq6knchBATekfavwHSJ6VXh5lkqfxE7zwpDPOF4h3ixhfgcyTqTzw3LY3E7cV2w5R3f9DMRT7jMOY7xJ1u3MlPDoGmZUF59U+5CSu6qmnUISOwdwRZnO2zI7wnV91+k/THROdlOpUqjQC0k7xBTJkg98nmHRzzzSbgg/VjzDuE3SU1jWYXPXLBtfKl5DpUJqG3KrNNFJ9Cug4BNvDI3fDMejOTX0QP+FKYTse6RwDqXxIRQ8w4bkcyv5sQ6bSyJaP/Eplqybs1lq14pktYirlQC+amDoUmlJc4zRR4KkNITe77rdApX03ZHwM6/0+5iuAIcAg6BXQgBxzu7UGO7qjoEsgQBxztZ0hBODIfALoSA451dqLFdVR0CWYKA450saQgnhkNgF0LA8c4u1Niuqg6BLEHAZh2dWZ0NLl2T5WL5UnS665dY/g4sFrOr4jJB7MNu0i1wID+VGOHEU4boZKgNElWS7gZJbfepePybfYuotulIcpBLLoZDWRWexuYLl5WVdNmcKOVzv7idE+1TV6ZR2MDFQBSLPE44S5qznXjHEBvdPo3h5SqrjyIe3EqIFJspBO8w4qRYqFXF2ERCeWzzZVqY0NKn94WOPvfLqjZBtaJ/cb1O2nJZ0pztwTvJdTYrwI2J5PVJXqIUmym5glMs1AgSnyBYnrj7JTV7MbQ4HfpCyHO/AtCxJis7x6FzH26Xkyo9BUChCPxjhZbpeYf86m2Min3iu+GDgcuWyeJjfjyzePU5Geif5Iu3qSoY5GyFpwwfOQYyhIUaxWRl03LVCP5k2laX0N+gUEwuVDuk+HCNosKW7yeMmgV2qxnVLJ6RqDD65mPkZDCUnVgndz4wuYvNx2lIIAdVs/Lx89KWjclnr9jm1k8DY4U89ysBnS+dpLuxRgjRDJJIld6iDnwjyfucYZ5F0OSUJPAncwSiMZmqOjrFpaUzUJjxlBnqkl0SaoQlFZdvjo23ZgDeQLMlZJFxfEAq9j1pff28OF6OHe9voyrpULNwvMMpD9UWX1ck7S6/IsBLLW0+ZTPZoMGmUTSfpf4HN+UoWt+iz5qShDz3i+Kr4gLJkOe3kB13yKWVvcsNwj5A2oGZg1DyJ1UgRmNUyVTV0fJOoruL/c0Kn/hIFLOcgvXVicTViAcqQNlbtwZu95AxjGpDWaKCnDD0Tx0+7LEEvPnMM2Va1Cwk7+iaz8vKuL6ibb6wmsZ0Favms9V/m9Y3kYrF7zbr6D4/E62IN1UcwoClhyR8U8bbQ5XeQkIzZ5HM5c0uH1GlA5Rq4JIs5ymro+tXsr5kwjOID8uuPNOGFomdbYjg0UmM/JTUYD1F1sfrLLkZW4HJz0ZV0qNm4XhHtqrL5JAATMk/uuaTWUycJyDR13hobZpPpZlEDbhfDa1v1Wv1iWx4R2IPy0dBcZ2D5R2ZOWJVA76wwGDHkKIsM6PGc7jbNY+q+irtobdwxUWMV4HlHTM+ut4eWiQiimR2SpSOnWqKkgmlcXOHFHnHBIWOd0zv6iaLumHDwDtsy0pOKRE7N0fWiqKVzRq2+ewUO34it771rXptSN6RVlTsvXJvimCbUIpQpbeqQtCqZv7y205r37YP7ygP90paca3wkXU3Wn9VDhqFk77CUYY8W4mWBJiHeyv0PMtEHqp5nBWMrKUXLCjp5uPVmJNPalTErlORuKhZA0RTo1DNZ8k7Vq1v1WlD8k6M8RSmXEL6IF0nIGDBICMn41emuYbSj8CozFCNYSwIGpCWuFsmUx7uxVbMF5UYDszXgIvdjCfbfPrermgRXV+ScbZYA4njTAY9qSO7piL5rsAn4P9TqRYLBctyyaqZAs7gooJ29k1z4HhGrpna5lMqnqZZwzSfpWJbtX778E6MbaWHRQWkJ4rGrQzHbPfYcrFygVM6oOmIhChXgscUvk3e+GkneyduNkuqz6By9vL48EHEoOvo8nVlFZ60maX4+MDE4JTloFC4BJ6C34D5CflaDd2JAV1YM2SbjIMtgQ+9cUeyFKyyfaiY3KmvRhjV9k5Q9fnmo/52qVIFALVX73jz6XhBUqPQzWfJO4mrj4hWSVu/3XgnDRnT+afJZE5bWS4jh4BDYCdBwM6vbF+ZwATK52nj8qJ95i6lQ8Ah0CkQSDfvcNMfRzqdQktcJRwC6UUg/byTXvlcbg4Bh0DnQ8DxTudrU1cjh0C2I+B4J9tbyMnnEOh8CEjvCxV3HagWaxNrsHaeHC4sicGTXyNm1g4DK2KJBURuoUzxgyIfdmmSic5NCCRGZHABq9L9YMg2tltEj6FfDknsf1XVKuzzzqegrkadEgEV74hxnIEgkeQWx1n2CqJJaIDmGoiVYpbI2OcBomL5TJE+GGOsJsCYYEHeYSiCEEbk7LOFm4Ipk8RITYNhgHaYmgRWAMM+75QK6irVKRGQ8w46FRew7HUzJjgtPO8wUV6B/c6xHuhfDKzYFUL7X2CRntmToYqJUsdK+czBXkMsNG6Qd/AXv9laFiQQS0Z+0mEYs3EkW/UT5QoSxERQPe+U+ukq1TkRUPAOAm0T1OIP9oi1NfOONKA2PpFAJ5P+TjiA/UnFF+Lch8ikMl7UvGM0d4IHdwi04xUrEk88WewXDYZkahU8w4UztHis4pVXPe+c+ulq1TkRUPEOtJs51IsETJt5x4SRhHfilkfgJ8U8S2LveH03lkXCFxLYhkCtKOZt/ysMLG7nBSs+y3FS2uGOMmOYJM5IGgwTtKM8mYgjWZpO9dyEvfvdIZA9CKh4x+s7se5Lhu0g7zCbt9hDE0z1EngnMd8RfkrQSMLy8p8Ft/Dgr1hKyjZBY0aST4DWYu4aftLFdG/f3otPDtluH7R4Esniz9UYMj5lGY/EAA9MBeO0qUpvwt797hDIHgSUvEPnAbHBvj3sHdbLEuAdkV9YUonvRPXOu433UGHNi7pOgjwlderwXTnmfUnspJfTTtDiYdiJ8lHcUJJhyC5lyY4Ec/ZO9vQSJ0m6EVDzDogn1qnjXTjd8yy/e/IfrzCuy6m8RvHnLH3FnUk+Z1jmI0x1grzDumkSxhMjN2ENJlnCDlJhyCVmWdPkx3H+nXT3AZdf5hHQ8I7fk+BOjner9vHvxKvMdicVXwS7XOIviWkQ9zezUxX6giI9b3IRNmCcO8F5lS+5YNoEHhI2EjEUHEb8YlmQ+XgeZDfbymy1zKuRK9EhEAoBHe8QeyQ2FrfHPIuVVDnPYuNumI4f4IDAy8wf7HyNzyfQ1SnFMNUllKWnHUo8ASbhxeQxDCRWnWoW/nmohneJHQIdiICOdwLL3la8o5oRyYwartKy6YPkTDEmsjfoqmEmbYKvR58Pe5ye4ISWeW2CkscLZkplOZGz42IL8Hz8U6LcYK3CPu9ATXJFOwTsEXD7s+yxcikdAg6B9CDgeCc9OLpcHAIOAXsEHO/YY+VSOgQcAulBwPFOenB0uTgEHAL2CDjescfKpXQIOATSg4DjnfTg6HJxCDgE7BHgeUcWQhy4tUqStWn1XHiFjfoNrBsLy9jBV7mCuHjn4Ok9wq1QyEq11p54Lj/fI3QFfbFV4inFiFdWKE4Ciyxwmt8DYpOPX6YBdq79dEWrkJQ911YhnCYYapCIAbHvGC5luyKgtnfsO5t9Sqrk8S7iqZfk1B1JYDB352YsJylPyNXMz5PdFCXZIMWKQ2EPhE+GaIyQYrCsw55lyKArhSWOKQ8FL7YqH5v8NbVmIWNipwNIqp6z2aagCWzLSnTRpzD5gBKiNV3StCKQcd7hunZCT4IB/0L4v5+QORtMsY08ZmeI2z8ltpKvi8HnotqK5Vri771oL0bA1mGraYBFxzoBuFT5WORvyToqJE0IC1UIqQmcRgXepmaT4x1Ltc1QsrC8w04emAN6LK/QFitFlZLv8UHlI504mEZlPavtDC6kWKKLvBSyci1bJhkxxOL0sNDpHEdw9vmY89dUV2l/xdhf1tllxnEwn7CawA1R7Ov4SXXanGUrumTtg0Ao3gnoR6J9ZapkKW1irOINHPbvuOkQKMh/VXJ2l+o5a40Hz1pOyCpRYa9HJ1PBJMSQVVMHiy+3ZGoYJh9j/pbGDp9MsFdjCWTPdQZLrIbsEMe3iOT1oKGZTPNZ6q9LliQCYXhHpaPJtqvABPwxNGS8TExY2IICLzOJVM9pJ42f3hM85Tlux3EmEZEoiQqGF0NeTRnmslMzEs0fLh9T/gbakRxnJEHSz0T1XHngYrzoBK/Iq0acysJpcEFE3DwrSYJop9dC8E5ccQIn5sT2OYb325HcZOc/kJrGO0RC1/T93zjAitopOwOMZmNbrmW70HwVYqiKM9gjQq3D5pO8vaMCnKULLcIqC0g3vKmm9j6q5OTL+GlwjncsVbNDkoXkHemwEd4c8NUkmBefSUz7pGRno868+kumUKrFsLhPQHomGdNKrGym8TRevEIMZTUVsKj6bOh8LGCXV81EO8KpaxS44JtiPhYi0ZZR2Ft61eqQjuYKDSAQgndUTpGw0xC/b4gKY1JHbr4jGRVlZ33Rc6FVvGMz4IcnVtnkQSaeNOfAQx0sBrms8rGAXdZlJEWrkNQiLKuChUjsa8EsJBkm0XyOJdoZgTC8Q6bodCyh8+5Q7apOnJjHS66IoS6CQHSg5Owuxh0Um67F3mAnOBZngLG4h6pg7EV2wsPetKMSg7OjEiO2BhaDzREUW5WPGXaZCsqKVlVZ9ZydTgfKMIsUqBozkEnHtGSar5273S6ffSjeiZkccStXEvCn7D3xH/TzJjpNl1+qJ7PA7c/0YuNyg5M8Rqg0TST96iZqEyxO9ZzFKCCHAhZTfxJ+V8FrgF3SSVRFq5DUPVdOd0nTyibVgomtrYEJp12eBDoAALc/qwNAd0U6BHZxBBzv7OIK4KrvEOgABBzvdADorkiHwC6OgOOdXVwBXPUdAh2AgOOdDgDdFekQ2MURcLyziyuAq75DoAMQEHlHutLNLAQnViUlKaWLnspqyYriN15sXb48uJMqYyAFpTMFJGdMLKag0BLqlr+TqqByiZqJFeCvbGXCwJkyEy8EBVE9F/BGQr4KYfO0KStsngk5OW1PCBs6jEMiA4t3HOB0nwOXkFPVRIqoB0nfkPMO34BsOFaQd8Q4k3DUw4rEhIvFHndc5AUfgBYI9+sIjhHKTEbCDPGOOjZSQg5exRi5AtVik4vaweuOGJQV085AnqqyVM/ZUlJ5l0bOB1vSly3ei2R1JL09yFKyeul7knhsXti6MJGirJgWcbCy7mLHO+xmGw3vhN0xERBIhXlS43CqzOBVkiNQvd6nWmDo95OSMDO8wyHFKbhkXAoGP9O/OGnNthWrKoo8uQ0siVSq9Hx3lu1ktnmXi6OPZ2uqo/97FpwDF5Qz8Ze6rfUanRneMdstAdokyb2NxVw0MmOR0vZXtZyQSUJjmGwUR2AaBQ4jSWxAT8wvVJIwXZIV0Spil29maR1JtW6Nb94OnB4R2IASk9USZP1EmMFSbu7wYMe7scI44muKZOLhXqo8wz5XWDv+47icqjyDglrVXaLMwePuzGX5Dd/O58Apu4ex38QxseMdlhU09o6loohMyGFFiwhUg03EfNfxTvDw5lhrBEYnWStRpSIHK4i9KglJmGzo2xLJiYgBoZRNGZ/SyyRU1JGQEbu/JVEgeZpa1WRjHDMi+l/Fo9qC5gLtz54ogCNeTYPvgINJkafysB9VerW5k+Adm3fJjkDJMXU+4PJ5VgyAwCzCWJbELA+TjzF/lnCF5rafE9j6lYNDNKOj/GERSbh3hL4v5R0OEaM1ruSyrQEi0TI06af84J+MJDJY4vogGcADAxavC/wYLEq4VVFHI78nUzXdRDjQqwJ/MEe1yXQdmcYIhyKnH9UseMcTVFGW8rmJd3R5Cu0UdNIEZ2zx44Oocia0g62aSv54WaKuhMvHkH+8QyhHY1uviMne4XQlNiImeEfi2bYtOgaVxOJQ8Q6bszQNK57KDiLFJkZRhU0jI4PYuMR1AKMkbGlB/pGO5QGy42eamlmznxnv4qCc5P+gwoQ+D1s1C9ZWD0RxHVeMscLgqeNfvmpZZ+9wDUfl81sthhFpeWryyg45M9gjAkTs2GbiL688K3tHcrYSI7pGRRM/mXgn3kVV9o5s6TKMySNhHaZ7cEilh3dIZ2cnG3ZMmXTnTKBNeUbis6abr7V9WduoiTcVdcwg7wgsKEoe13G+wrHngjkYhncUeUo3snuNoUrP2ywy17XNuyqblqtTPCvp2GOWU0o7/IzEJ7aw+Ghtcou25t+34J3YcC2yr6yDaHVDUD0p66h5hx3NaUHGvkRKVbGGMKoGEkvVjnvFKIlpHsXbyFKRuEyk5GSsoxGrsFVTcKS8XSVjKenGwR8CpgBL0JwxFkRE3/kTJSjKUq5zsaWk8K6q7greCdQtUDWVDEq1TWRllY99W8SsNEUfNlg9VrwTO5Ob6EBCelHpwg3VSomD4zZLeAGLNPYD21fIOKGdU4jJZb5jgcJZYVXfFZKodEupc37+dGRV0JBOQlUdjbyj8isHzppUg8xRPK97QQuGoRFGXh7bwDKbxjAVVE+RJ3/kG/WkqdLzxBOTIaC8Fu+q6u43Y1zF5U0drJqmLJ7ctGNVSHwU8ofr8aHmWdRcIH0hyDucEadQDLl0PuQyK5BJHksTmADTGUm8GqQjxB7H1VnVx/jzuJSNxeQqLmwFigwOKYIksRE96Goh7wQg4KeRRt+ORkIm45iLVmJdU4gCWIWpmqxhOani7SJUWOIaFFrWeKczhV4mSQIEC7daoDX0TqlglfiKKd8NtklCaVTPWfUOgKWol4kDpNQcoi5Mw7JeCuk8zmDu7HD7s0wIud8dAg6BdCPgeCfdiLr8HAIOARMCjndMCLnfHQIOgXQj4Hgn3Yi6/BwCDgETAo53TAi53x0CDoF0I+B4J92IuvwcAg4BEwKOd0wIud8dAg6BdCPgeCfdiLr8HAIOARMCjndMCLnfHQIOgXQj4Hgn3Yi6/BwCDgETAo53TAi53x0CDoF0I+B4J92IuvwcAg4BEwKOd0wIud8dAg6BdCPgeCfdiLr8HAIOARMCjndMCLnfHQIOgXQj4Hgn3Yi6/BwCDgETAo53TAi53x0CDoF0I+B4J92IuvwcAg4BEwKOd0wIud8dAg6BdCPgeCfdiLr8HAIOARMCjndMCLnfHQIOgXQj4Hgn3Yi6/BwCDgETAo53TAi53x0CDoF0I/D/xOH6r1qloEUAAAAASUVORK5CYII=',
          fit: [150, 200]
      },
          {
          text:'Bon D\'entrée ' , style: 'center',color : '#B22222'
          },
  
          { 
              text:  new Date().toLocaleString(), alignment: 'right'
          },
          ]
      },
      {
          columns: [
              
              {
                  text: 'N° :fg147 ',style :'textSize',alignment:'center'
              },
             
          ]
      },
      '\n','\n', '\n',
      {
          columns: [
              {
                  text: 'Fournisseur : ',style :'textSize'
              },
              {
                  text: this.fournisseurObj.fournisseur,style : 'Size'
              },
              {
                  text: 'transporteur : ',style :'textSize',alignment:'center'
              },
              {
                  text: this.fournisseurObj.transporteur,style : 'Size'
              },
              {
                  text: 'GSM :  ',style :'textSize',alignment:'right'
              },
              {
                  text: this.fournisseurObj.gsm,style : 'Size'
              },
          ]
      },
  
      {
        columns: [
          {text: 'Equipe Technique : ', style: 'textSize'},
          { text: this.fournisseurObj.equipeTechn,style:'Size'},
          {text: '', style: 'textSize'}, {text: '', style: 'textSize'},
        ]
      },'\n','\n',
      {
         
          table: {
              widths: ['auto', '*','auto','auto'],
              body: [
                  ['N°', 'Designation', 'Quantité','Action'],
                  ['1', 'prod1', '25' ,'']
              ]
          }
      }
  ],
  
  styles: {
      header: {
          bold: true,
          fontSize: 9,
      },
      center :{
          bold:true,
          
          alignment :'center',
          fontSize : 25
      },
      textSize: {
          fontSize: 12,
          bold : true
      },
      Size: {
          fontSize: 10,
          bold : false
      },
  
  
  },
  pageSize: 'A4',
  pageOrientation: 'portrait'
  };
  pdfmake.createPdf(makePdf).open();
  }
  //---------------------------------------------------

  scan() {
    this.options = {
      prompt: "Scannez le code "
    }
    this.barcodeScanner.scan(this.options).then((barcodeData) => {

      console.log(barcodeData);
      this.scanData = barcodeData;
    }, (err) => {
      console.log("erreur est survenu : " + err);
    });
  }

  valider() {

    if (!this.validate()) {
      return;
    }

    let ligneProduit: LigneProduit;

    let filteredLigneProduitIndex = this.Fiche.LignesProduits.findIndex(item => item.Produit.Designation == this.scanData.text);

    if (filteredLigneProduitIndex != -1) {
      ligneProduit = this.Fiche.LignesProduits[filteredLigneProduitIndex];
      ligneProduit.Quantite += Number(this.scanData.Quantite);
    }
    else {
      
      ligneProduit = new LigneProduit();
      ligneProduit.Produit.Designation = this.scanData.text;
      ligneProduit.Quantite = Number(this.scanData.Quantite);
      
      ligneProduit.Fiche_Id = this.Fiche.Id;
      this.Fiche.LignesProduits.push(ligneProduit);
    }

    this.clearData();
  }
  clearData() {
    this.scanData.text = "";
    this.scanData.Quantite = "";
  }
  delete(Produit_Id) {
    let filteredLigneProduitIndex = this.Fiche.LignesProduits.findIndex(item => item.Produit.Designation == Produit_Id);

    if (filteredLigneProduitIndex != -1) {

      this.Fiche.LignesProduits.splice(filteredLigneProduitIndex, 1);
    }
  }
  validate(): boolean {
    let isValid: boolean = true;
    let message = "";
    if (this.scanData.text == "") {
      message = "Veuillez entrer un nom produit valide!</br>";
      isValid = false;
    }
    if (this.scanData.Quantite <= 0) {
      message = "Veuillez entrer une quantité valide!";
      isValid = false;
    }
    if (!isValid) 
    {
      let toast = this.toastCtrl.create({
      message: 'Produit ajouté avec succès !',
      duration: 5000
      });
      toast.present();
    }
    return isValid;
  }
  retour()
  {
    this.navCtrl.push(MenuPage);
  }
  // getAllFiches() {
  //   let getAllFiches = this.dataService.getFiches();
  //   getAllFiches  
  //    .then(
  //         res => { // Success   
  //           this.Fiches = <Array<Fiche>> res;
  //         },
  //         (error) => console.error(error)
  //     );
  // }
  getDetails(ficheId : Guid){}
  sauvegarder()
  {
    this.dataService.addFiche(this.Fiche).subscribe(
      () => {
        this.toastCtrl.create({
          message: 'Fiche ajoutée avec succès !',
          duration: 5000
          });
      }
    );
    this.navCtrl.setRoot(FicheEntreePage);
  }
}
