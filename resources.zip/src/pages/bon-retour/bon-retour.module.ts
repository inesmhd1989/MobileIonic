import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BonRetourPage } from './bon-retour';

@NgModule({
  declarations: [
    BonRetourPage,
  ],
  imports: [
    IonicPageModule.forChild(BonRetourPage),
  ],
})
export class BonRetourPageModule {}
